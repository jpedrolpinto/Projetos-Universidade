-- Universidade do Minho
-- Bases de Dados 2024
-- Caso de Estudo: Hospital Portucalense

-- -----------------------------------------------------
-- Indicação da base de dados de trabalho
-- -----------------------------------------------------
USE Agencia;

-- -----------------------------------------------------
-- Povoamento da tabela `diretor`
-- -----------------------------------------------------
INSERT INTO diretor(id, nome, email, telefone) VALUES
('01', 'Pinguim', 'pinguim_director@gmail.com', '943231765');

-- -----------------------------------------------------
-- Povoamento da tabela `detetive`
-- -----------------------------------------------------
INSERT INTO detetive(n_identificação, data_nascimento, disponibilidade, telefone, fk_idDiretor) VALUES
('001', '1998-04-21', 'disponivel', '941221667', '01'),
('002', '1991-02-11', 'disponivel', '932521863', '01'),
('003', '1991-05-13', 'disponivel', '961320161', '01'),
('004', '1996-10-08', 'disponivel', '931221365', '01'),
('005', '1999-11-27', 'disponivel', '961021668', '01'),
('006', '2000-12-19', 'disponivel', '941195669', '01'),
('007', '1997-01-10', 'disponivel', '960221660', '01');

-- -----------------------------------------------------
-- Povoamento da tabela `ajudante`
-- -----------------------------------------------------
INSERT INTO ajudante(id_ajudante, nome, data_nascimento, especializacao, fk_nDetetive) VALUES
('111', 'Alberto', '1998-04-21', 'Armas', '001'),
('222', 'José', '1991-02-11', 'Carros', '002'),
('333', 'Manuel', '1991-05-13', 'Armas', '003'),
('444', 'António', '1996-10-08', 'Computadores', '004'),
('555', 'João', '1999-11-27', 'Carros', '005'),
('666', 'Carlos', '2000-12-19', 'Armas', '006'),
('777', 'Tijolinho', '1997-01-10', 'Computadores', '007');

-- -----------------------------------------------------
-- Povoamento da tabela `cliente`
-- -----------------------------------------------------
INSERT INTO cliente(id_Cliente, nome, data_nascimento, estatuto, telefone, fk_idDiretor_Cliente) VALUES
('01','Rei Carlos', '1972-04-21', 'Rei', '941221667', '01'),
('02','Rainha Isabel', '1970-11-29', 'Rainha', '941221667', '01'),
('03','Princesa Inês', '1999-12-30', 'Princesa', '941221667', '01'),
('04','Dom Afonso Henriques', '1998-08-03', 'Rei', '941221667', '01'),
('05','Dona Maria II', '1969-10-25', 'Rainha', '941221667', '01'),
('06','Dom Dinis', '1966-03-10', 'Rei', '941221667', '01'),
('07','Dom Sancho Pança', '2004-06-28', 'Principe', '941221667', '01');

-- -----------------------------------------------------
-- Povoamento da tabela `tipo`
-- -----------------------------------------------------
INSERT INTO tipo(id_Tipo, descricao) VALUES
('01', 'Homicidio, aconteceu a morte de uma pessoa e cre-se que esta foi morta por outra pessoa!'),
('02', 'Suicidio, aconteceu a morte de uma pessoa e cre-se que a mesma se matou!'),
('03', 'Rapto, indiciduo desaparecido, acredita-se que tenha sido levado'),
('04', 'Roubo, bens de um certo individuo desapareceram ou foram levados!'),
('05', 'Terrorismo, atentados diversos!');

-- -----------------------------------------------------
-- Povoamento da tabela `caso`
-- -----------------------------------------------------
INSERT INTO caso(numero, dta_inicio, dta_fim, provas, fk_idTipo, fk_idCliente, fk_nDetetive_Caso) VALUES
('01', '1998-04-21', '1998-04-21', 'Arma do crime', '01', '01', '001'),
('02', '1998-04-21', '1991-02-11', 'Forca', '02' '02', '003'),
('03', '1998-04-21', '1991-05-13', 'Marcas de pneus', '03' '03', '005'),
('04', '1998-04-21', '1996-10-08', 'Impressões digitais', '04' '04', '002'),
('05', '1998-04-21', '1999-11-27', 'Ameaças de Bomba', '05' '05', '006'),
('06', '1998-04-21', '2000-12-19', 'Descrição do assassino', '01' '06', '007');